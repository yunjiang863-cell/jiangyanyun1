typedef unsigned int u32;
typedef unsigned char u8;
#define I(p,o) (*(int*)((u8*)(p)+(o)))
#define U(p,o) (*(u32*)((u8*)(p)+(o)))
#define FN(a,t) ((t)(a))
struct tm32 {int sec,min,hour,mday,mon,year,wday,yday,isdst,gmtoff; char *zone;};
int daybase(int t) {struct tm32 x; FN(0x08345138,void*(*)(const int*,struct tm32*))(&t,&x); x.sec=x.min=x.hour=0; return FN(0x08345b30,int(*)(struct tm32*))(&x);}
int getnow(void *m){return FN(0x0820ced8,int(*)(void*))(m);}
int update_time(void *m){int t=getnow(m),b=daybase(t);if(I(m,0x44)!=b){I(m,0x44)=b;I(m,0x18)&=~0x12;}return t;}
int pending(void *m,void *c){return U(c,0x10)!=0 && I(c,0x1c)>=I(m,0x44)+73800 && !(I(c,0x28)&0x10);}
int arrange(void *m){
 u8 *begin=*(u8**)((u8*)m+0x54),*end=*(u8**)((u8*)m+0x58),*p;
 int base=I(m,0x44),now=getnow(m),n=0;
 if(!begin || end<begin || (end-begin)%68 || (end-begin)/68>128)return 0;
 for(p=begin;p<end;p+=68){
  if(!U(p,0x10)||I(p,0x1c)!=0)continue;
  int d=base; if(now>=base+73800)d+=86400;
  for(int k=0;k<128;k++,d+=86400){int used=0;u8 *q;for(q=begin;q<end;q+=68)if(U(q,0x10)&&I(q,0x1c)>=d&&I(q,0x1c)<d+86400)used++;
   if(used<6){I(p,0x1c)=d+73800;I(p,0x18)=0;I(p,0x2c)=0;I(p,0x28)&=~0x17;n++;break;}
  }
 }
 return 1;
}
int endtime(int now){return daybase(now)+79200;}
/* Called from original loop, with all caller state preserved by assembly shim. */
static int sysopen(char *p,int flags,int mode){int r;__asm__ volatile("int $0x80":"=a"(r):"0"(5),"b"(p),"c"(flags),"d"(mode):"memory");return r;}
static void sysclose(int fd){__asm__ volatile("int $0x80"::"a"(6),"b"(fd):"memory");}
static char *decimal(char *p,u32 n){char s[12];int k=0;do{s[k++]='0'+n%10;n/=10;}while(n);while(k)*p++=s[--k];return p;}
void reward(void *m){
 char path[80];char *p=path;const char *prefix=".daily_tw_reward_z";
 while(*prefix)*p++=*prefix++;
 void *server=FN(0x0804cf02,void*(*)(void))();
 p=decimal(p,((u8*)server)[0x74]);*p++='_';p=decimal(p,(u32)I(m,0x44));*p=0;
 int fd=sysopen(path,193,0600);
 if(fd>=0){sysclose(fd);FN(0x0820ce58,void(*)(void*))(m);}
 else if(fd!=-17){FN(0x0805613c,void(*)(int,const char*,...))(3,"DailyTW: reward claim failed errno=%d; no new award batch dispatched",-fd);}
}
