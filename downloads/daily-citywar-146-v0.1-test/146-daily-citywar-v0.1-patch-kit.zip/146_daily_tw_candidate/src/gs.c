typedef unsigned int u32;typedef unsigned char u8;
#define I(p,o) (*(int*)((u8*)(p)+(o)))
#define U(p,o) (*(u32*)((u8*)(p)+(o)))
#define FN(a,t) ((t)(a))
struct entry{void *ctrl;int end;volatile u32 seen;u32 checked;};
static struct entry entries[512];
static volatile int guard;
static void lock(void){while(__sync_lock_test_and_set(&guard,1)){} }
static void unlock(void){__sync_lock_release(&guard);}
static struct entry *find(void *c,int create){u32 h=((u32)c>>4)%512;for(u32 i=0;i<512;i++){struct entry *e=&entries[(h+i)%512];if(e->ctrl==c){if(e->end!=I(c,0x1c)){e->end=I(c,0x1c);e->seen=e->checked=0;}return e;}if(!e->ctrl&&create){e->ctrl=c;e->end=I(c,0x1c);e->seen=e->checked=0;return e;}}return 0;}
int nowtime(void){return FN(0x082a79d0,int(*)(void*))( (void*)0x08c4ea80);}
void init_ctrl(void *c){lock();struct entry *e=find(c,1);if(e){e->end=I(c,0x1c);e->seen=e->checked=0;}unlock();}
void mark_enter(void *c,int flags){int t=nowtime();lock();struct entry *e=find(c,1);if(e && t<I(c,0x1c)-4800)e->seen|=(u32)flags&3;unlock();}
void tick(void *c,void *w){
 if(I(c,0x50))return;
 int t=nowtime();lock();struct entry *e=find(c,1);int result=0;
 if(e && !e->checked && t>=I(c,0x1c)-4800){
  e->checked=1;u32 seen=e->seen;
  if(!(seen&1))result=2;
  else if(U(c,0x08)!=0 && !(seen&2))result=1;
 }
 unlock();
 if(result){I(c,0x50)=result;FN(0x081a3fd4,void(*)(void*,void*))(c,w);return;}
 FN(0x081a3e9c,void(*)(void*,void*))(c,w);
}
