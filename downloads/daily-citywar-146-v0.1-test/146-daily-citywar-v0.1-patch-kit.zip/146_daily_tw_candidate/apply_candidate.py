#!/usr/bin/env python3
"""Build test-only copies. Never modify inputs, start services or connect to a database."""
import argparse,hashlib,json,struct,os
from pathlib import Path
BASE=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def apply(src,spec,out):
 original=src.read_bytes()
 if sha(original)!=spec['input_sha256']:raise ValueError(f'Original hash mismatch: {src}')
 data=bytearray(original)
 for p in spec['patches']:
  off=p['offset'];old=bytes.fromhex(p['old']);new=bytes.fromhex(p['new'])
  if data[off:off+len(old)]!=old:raise ValueError('Patch site mismatch: '+p['label'])
  data[off:off+len(old)]=new
 payload=(BASE/spec['payload_file']).read_bytes()
 if sha(payload)!=spec['payload_sha256']:raise ValueError('Payload hash mismatch')
 off=(len(data)+4095)&~4095;po=spec['note_ph_offset']
 if data[po:po+32]!=bytes.fromhex(spec['note_ph_old']):raise ValueError('Unexpected program header')
 # Add a LOAD at a spare ABI NOTE header. Do not move any original file data.
 phoff=struct.unpack_from('<I',data,28)[0];ps,pn=struct.unpack_from('<HH',data,42)
 for i in range(pn):
  ph=struct.unpack_from('<8I',data,phoff+i*ps)
  if ph[0]==1 and max(spec['base'],ph[2])<min(spec['base']+spec['memsize'],ph[2]+ph[5]):raise ValueError('Address overlap')
 data[po:po+32]=struct.pack('<8I',1,off,spec['base'],spec['base'],len(payload),spec['memsize'],7,4096)
 data.extend(bytes(off-len(data)));data.extend(payload)
 out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('xb') as f:f.write(data)
 os.chmod(out,0o755)
 return {'input':str(src),'output':str(out),'input_sha256':sha(original),'output_sha256':sha(data),'patch_sites':len(spec['patches'])}

def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--delivery',required=True,type=Path);a.add_argument('--gs',required=True,type=Path);a.add_argument('--domain',required=True,type=Path);a.add_argument('--output',required=True,type=Path);a.add_argument('--ack-test-only',action='store_true');args=a.parse_args()
 if not args.ack_test_only:a.error('This unvalidated candidate is for an isolated test server only; read README.md and pass --ack-test-only.')
 if args.output.exists():raise ValueError('Output directory must not exist; inputs will never be overwritten')
 specs=json.loads((BASE/'patch-spec.json').read_text());db=args.domain.read_bytes();expected=json.loads((BASE/'domain-spec.json').read_text())
 if sha(db)!=expected['input_sha256']:raise ValueError('domain.sev hash mismatch')
 for src,key in [(args.delivery,'delivery'),(args.gs,'gs')]:
  if sha(src.read_bytes())!=specs[key]['input_sha256']:raise ValueError('Input hash mismatch: '+str(src))
 args.output.mkdir(parents=True)
 records=[apply(args.delivery,specs['delivery'],args.output/'gdeliveryd/gdeliveryd'),apply(args.gs,specs['gs'],args.output/'gamed/gs')]
 data=db[:expected['territory_end']]+struct.pack('<5i',1,0,20,30,6);out=args.output/'gdeliveryd/domain.sev';out.write_bytes(data)
 records.append({'input':str(args.domain),'output':str(out),'input_sha256':sha(db),'output_sha256':sha(data),'territories_preserved':51})
 (args.output/'build-manifest.json').write_text(json.dumps({'status':'TEST_ONLY_NOT_PRODUCTION_VERIFIED','records':records},ensure_ascii=False,indent=2))
 print(json.dumps({'output':str(args.output),'status':'TEST_ONLY_NOT_PRODUCTION_VERIFIED','records':records},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
