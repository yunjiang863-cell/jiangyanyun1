from pathlib import Path
import subprocess,json
from elftools.elf.elffile import ELFFile
w=Path(__file__).resolve().parent
result={}
for name in ['delivery','gs']:
 subprocess.run(['gcc','-m32','-Os','-fno-pic','-fno-pie','-fno-stack-protector','-fno-asynchronous-unwind-tables','-ffreestanding','-fno-builtin','-c',str(w/'src'/f'{name}.c'),'-o',str(w/f'{name}.o')],check=True)
 subprocess.run(['as','--32',str(w/'src'/f'{name}_hooks.S'),'-o',str(w/f'{name}_hooks.o')],check=True)
 subprocess.run(['ld','-m','elf_i386','-T',str(w/'src/payload.ld'),str(w/f'{name}.o'),str(w/f'{name}_hooks.o'),'-o',str(w/f'{name}-payload.elf')],check=True)
 subprocess.run(['objcopy','-O','binary',str(w/f'{name}-payload.elf'),str(w/f'{name}-payload.bin')],check=True)
 with (w/f'{name}-payload.elf').open('rb') as f:
  e=ELFFile(f);syms={x.name:x['st_value'] for x in e.get_section_by_name('.symtab').iter_symbols() if x.name};memend=max(s['sh_addr']+s['sh_size'] for s in e.iter_sections() if s['sh_flags']&2)
 result[name]={'base':0x9000000,'memsize':memend-0x9000000,'symbols':syms}
(w/'payloads.json').write_text(json.dumps(result,indent=2))
print({k:{'bytes':(w/f'{k}-payload.bin').stat().st_size,'memsize':v['memsize']} for k,v in result.items()})
