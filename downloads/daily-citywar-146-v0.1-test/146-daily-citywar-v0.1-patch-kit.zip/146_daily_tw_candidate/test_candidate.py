import unittest,struct,json
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
from collections import Counter
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE,UC_HOOK_INTR
from unicorn.x86_const import *
W=Path(__file__).resolve().parent
TZ=ZoneInfo('Asia/Shanghai');BASE=int(datetime(2026,11,3,tzinfo=TZ).timestamp())
STOP=0x30000000;STACK=0x21000000;HEAP=0x20000000
P=lambda n:struct.pack('<I',n&0xffffffff)
class Machine:
 def __init__(self,name,claims=None):
  self.name=name;self.u=Uc(UC_ARCH_X86,UC_MODE_32);u=self.u
  path=W/'output'/('gdeliveryd/gdeliveryd' if name=='delivery' else 'gamed/gs')
  with path.open('rb') as f:
   elf=ELFFile(f)
   for s in elf.iter_segments():
    if s['p_type']!='PT_LOAD':continue
    a=s['p_vaddr']&~4095;z=(s['p_vaddr']+s['p_memsz']+4095)&~4095;u.mem_map(a,z-a);u.mem_write(s['p_vaddr'],s.data())
  for a,size in [(HEAP,0x20000),(STACK,0x20000),(STOP,4096)]:u.mem_map(a,size)
  u.mem_write(STOP,b'\xf4');self.now=BASE+70000;self.events=[];self.claims=claims if claims is not None else set();self.stubs={}
  self.symbols=json.loads((W/'payloads.json').read_text())[name]['symbols']
  if name=='delivery':
   self.stubs.update({0x820ced8:lambda a:self.now,0x8345138:self.localtime,0x8345b30:self.mktime,0x804cf02:lambda a:HEAP+0x18000,0x820ce58:self.reward,0x805613c:self.log})
   u.mem_write(HEAP+0x18000+0x74,b'\x02')
  else:self.stubs.update({0x82a79d0:lambda a:self.now,0x82c4388:self.send_end})
  u.hook_add(UC_HOOK_CODE,self.code);u.hook_add(UC_HOOK_INTR,self.intr)
 def get(self,a):return struct.unpack('<I',self.u.mem_read(a,4))[0]
 def put(self,a,n):self.u.mem_write(a,P(n))
 def cstr(self,a):
  out=bytearray()
  while (b:=self.u.mem_read(a,1))!=b'\0':out+=b;a+=1
  return out.decode()
 def args(self,n=5):s=self.u.reg_read(UC_X86_REG_ESP);return [self.get(s+4+i*4) for i in range(n)]
 def code(self,u,a,size,_):
  if a in self.stubs:
   result=self.stubs[a](self.args());sp=u.reg_read(UC_X86_REG_ESP);ret=self.get(sp);u.reg_write(UC_X86_REG_EAX,(result or 0)&0xffffffff);u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret)
 def intr(self,u,n,_):
  assert n==0x80
  op=u.reg_read(UC_X86_REG_EAX)
  if op==5:
   path=self.cstr(u.reg_read(UC_X86_REG_EBX));flags=u.reg_read(UC_X86_REG_ECX);assert flags==193
   if path in self.claims:r=-17
   else:self.claims.add(path);r=3
  elif op==6:r=0
  else:raise AssertionError(op)
  u.reg_write(UC_X86_REG_EAX,r&0xffffffff)
 def localtime(self,a):
  d=datetime.fromtimestamp(self.get(a[0]),TZ);x=[d.second,d.minute,d.hour,d.day,d.month-1,d.year-1900,(d.weekday()+1)%7,d.timetuple().tm_yday-1,0,28800,0];self.u.mem_write(a[1],struct.pack('<11i',*x));return a[1]
 def mktime(self,a):
  x=struct.unpack('<11i',self.u.mem_read(a[0],44));return int(datetime(x[5]+1900,x[4]+1,x[3],x[2],x[1],x[0],tzinfo=TZ).timestamp())
 def reward(self,a):self.events.append(('reward',));return 0
 def log(self,a):self.events.append(('log',));return 0
 def send_end(self,a):self.events.append(('end',*a[:4]));return 0
 def call(self,target,*args):
  if isinstance(target,str):target=self.symbols[target]
  sp=STACK+0x10000;self.u.mem_write(sp,P(STOP)+b''.join(P(x) for x in args));self.u.reg_write(UC_X86_REG_ESP,sp);self.u.reg_write(UC_X86_REG_EBP,0);self.u.emu_start(target,STOP,count=1000000);assert self.u.reg_read(UC_X86_REG_EIP)==STOP,'Instruction budget exceeded';return self.u.reg_read(UC_X86_REG_EAX)
 def manager(self,n):
  m=HEAP;p=HEAP+0x1000;self.put(m+0x44,BASE);self.put(m+0x54,p);self.put(m+0x58,p+68*n);self.put(m+0x5c,p+68*n)
  for i in range(n):self.put(p+i*68+0x10,100+i)
  return m,p
 def ctrl(self):
  c=HEAP;self.put(c+4,1);self.put(c+8,101);self.put(c+12,202);self.put(c+0x1c,BASE+79200);self.put(c+0x50,0);self.call('init_ctrl',c);return c,HEAP+0x2000
class DeliveryTests(unittest.TestCase):
 def test_queue_limits(self):
  for n in [0,1,6,7,12,13,51]:
   with self.subTest(n=n):
    x=Machine('delivery');m,p=x.manager(n);self.assertEqual(x.call(0x820f432,m),1);times=[x.get(p+i*68+0x1c) for i in range(n)];expected=[BASE+73800+(i//6)*86400 for i in range(n)];self.assertEqual(times,expected);self.assertTrue(all(v<=6 for v in Counter(times).values()))
 def test_existing_queue_first(self):
  x=Machine('delivery');m,p=x.manager(13)
  for i in range(7):x.put(p+i*68+0x1c,BASE+73800+(i//6)*86400)
  x.call('arrange',m);self.assertEqual([x.get(p+i*68+0x1c) for i in range(13)],[BASE+73800+(i//6)*86400 for i in range(13)])
 def test_queue_idempotent_and_metadata_reload(self):
  x=Machine('delivery');m,p=x.manager(13);x.call('arrange',m);data=bytes(x.u.mem_read(p,13*68));x.call('arrange',m);self.assertEqual(bytes(x.u.mem_read(p,13*68)),data)
  y=Machine('delivery');m2,p2=y.manager(13);y.u.mem_write(p2,data);y.put(m2+0x44,BASE+86400);y.now=BASE+86400+70000;y.call('arrange',m2);self.assertEqual(bytes(y.u.mem_read(p2,13*68)),data)
 def test_after_start_next_day(self):
  x=Machine('delivery');m,p=x.manager(7);x.now=BASE+73800;x.call('arrange',m);self.assertEqual(x.get(p+0x1c),BASE+86400+73800)
 def test_daily_anchor_and_flags(self):
  for offset in [0,46800,70200,73800,79200,81000,86400,86401]:
   x=Machine('delivery');m,p=x.manager(0);x.put(m+0x44,BASE-86400);x.put(m+0x18,0xff);x.now=BASE+offset;self.assertEqual(x.call(0x820dfdc,m),x.now);self.assertEqual(x.get(m+0x44),BASE+(offset//86400)*86400);self.assertEqual(x.get(m+0x18),0xed)
 def test_fixed_end_and_time_helpers(self):
  x=Machine('delivery');m,p=x.manager(0)
  for a,n in [(0x82125f0,46800),(0x8212600,70200),(0x8212610,70200),(0x8212620,81000)]:self.assertEqual(x.call(a,m),BASE+n)
  for n in [73800,73900,75000,79199]:self.assertEqual(x.call('endtime',BASE+n),BASE+79200)
 def test_pending_protection(self):
  x=Machine('delivery');m,p=x.manager(1)
  for t,expect in [(0,0),(BASE+73800,1),(BASE+86400+73800,1),(BASE-86400+73800,0)]:x.put(p+0x1c,t);self.assertEqual(x.call('pending',m,p),expect)
 def test_reward_claim_across_restart_and_day(self):
  claims=set();x=Machine('delivery',claims);m,p=x.manager(0);x.call('reward',m);x.call('reward',m);self.assertEqual(len(x.events),1)
  y=Machine('delivery',claims);m,p=y.manager(0);y.call('reward',m);self.assertEqual(len(y.events),0);y.put(m+0x44,BASE+86400);y.call('reward',m);self.assertEqual(len(y.events),1)
 def test_begin_hook_preserves_future_queue(self):
  for future in [False,True]:
   x=Machine('delivery');m,p=x.manager(1);x.put(p+0x1c,BASE+73800 if future else 0)
   bp=STACK+0x8000;sp=STACK+0x7000;x.put(bp+8,m);x.u.reg_write(UC_X86_REG_EBP,bp);x.u.reg_write(UC_X86_REG_ESP,sp);x.u.reg_write(UC_X86_REG_EAX,p);x.u.reg_write(UC_X86_REG_EBX,0x12345678)
   target=0x820d058 if future else 0x820cfad
   x.u.emu_start(0x820cfa7,target,count=100000);self.assertEqual(x.u.reg_read(UC_X86_REG_ESP),sp);self.assertEqual(x.u.reg_read(UC_X86_REG_EAX),p);self.assertEqual(x.u.reg_read(UC_X86_REG_EBX),0x12345678)
 def test_absolute_end_hook_restores_caller_registers(self):
  x=Machine('delivery');sp=STACK+0x7000;x.u.reg_write(UC_X86_REG_ESP,sp);x.u.reg_write(UC_X86_REG_EAX,BASE+75000);x.u.reg_write(UC_X86_REG_ECX,17);x.u.reg_write(UC_X86_REG_EDX,23);x.u.emu_start(0x820e977,0x820e97c,count=100000);self.assertEqual(x.u.reg_read(UC_X86_REG_EAX),BASE+79200);self.assertEqual(x.u.reg_read(UC_X86_REG_ECX),17);self.assertEqual(x.u.reg_read(UC_X86_REG_EDX),23);self.assertEqual(x.u.reg_read(UC_X86_REG_ESP),sp)
 def test_reward_failure_does_not_issue_batch(self):
  class DeniedMachine(Machine):
   def intr(self,u,n,data):
    self.assert_open=(n==0x80 and u.reg_read(UC_X86_REG_EAX)==5)
    if not self.assert_open:raise AssertionError('Unexpected syscall')
    u.reg_write(UC_X86_REG_EAX,(-13)&0xffffffff)
  x=DeniedMachine('delivery');m,p=x.manager(0);x.call('reward',m);self.assertEqual(x.events,[('log',)])

class GSTests(unittest.TestCase):
 def scenario(self,seen,owner=101):
  x=Machine('gs');c,w=x.ctrl();x.put(c+8,owner);x.now=BASE+73800
  if seen&1:x.call('mark_enter',c,1)
  if seen&2:x.call('mark_enter',c,2)
  return x,c,w
 def test_absence_matrix(self):
  for seen,owner,result in [(0,101,2),(1,101,1),(2,101,2),(3,101,0),(1,0,0),(0,0,2)]:
   with self.subTest(seen=seen,owner=owner):
    x,c,w=self.scenario(seen,owner);x.now=BASE+74400;x.call(0x81a3e44,c,w);self.assertEqual(x.get(c+0x50),result);self.assertEqual(len(x.events),int(bool(result)))
 def test_not_before_ten_minutes(self):
  x,c,w=self.scenario(0);x.now=BASE+74399;x.call('tick',c,w);self.assertEqual(x.get(c+0x50),0)
 def test_entry_history_survives_leave(self):
  x,c,w=self.scenario(3);x.put(c+0x10,0);x.put(c+0x14,0);x.now=BASE+74400;x.call('tick',c,w);self.assertEqual(x.get(c+0x50),0)
 def test_late_entry_not_credited(self):
  x,c,w=self.scenario(0);x.now=BASE+74400;x.call('mark_enter',c,1);x.call('mark_enter',c,2);x.call('tick',c,w);self.assertEqual(x.get(c+0x50),2)
 def test_deadline_and_result_idempotence(self):
  x,c,w=self.scenario(3);x.now=BASE+79199;x.call('tick',c,w);self.assertEqual(x.get(c+0x50),0);x.now=BASE+79200;x.call('tick',c,w);self.assertEqual(x.get(c+0x50),3);self.assertEqual(len(x.events),1);x.call('tick',c,w);self.assertEqual(len(x.events),1)
 def test_new_instance_resets_history(self):
  x,c,w=self.scenario(3);x.call('init_ctrl',c);x.now=BASE+74400;x.call('tick',c,w);self.assertEqual(x.get(c+0x50),2)
 def test_hooks_restore_registers_and_stack(self):
  x=Machine('gs');c,w=x.ctrl();x.now=BASE+73800;ebp=STACK+0x8000;x.put(ebp+8,c);x.put(ebp+16,1);x.u.reg_write(UC_X86_REG_EBP,ebp);x.u.reg_write(UC_X86_REG_ESP,STACK+0x7000);x.u.emu_start(0x81a3ce4,0x81a3cea,count=100000);self.assertEqual(x.u.reg_read(UC_X86_REG_ESP),STACK+0x7000-12);self.assertEqual(x.u.reg_read(UC_X86_REG_EAX),ebp-24)
  x.now=BASE+74400;x.call('mark_enter',c,2);x.call('tick',c,w);self.assertEqual(x.get(c+0x50),1)
if __name__=='__main__':unittest.main(verbosity=2)
