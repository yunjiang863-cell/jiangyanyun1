from pathlib import Path
from elftools.elf.elffile import ELFFile
import json,hashlib,struct
w=Path(__file__).resolve().parent;root=w.parent
payloads=json.loads((w/'payloads.json').read_text());spec={}
for name,p in [('delivery',root/'146-original/gdeliveryd/gdeliveryd'),('gs',root/'146-gs/gs')]:
 b=p.read_bytes()
 with p.open('rb') as f:
  e=ELFFile(f);segs=list(e.iter_segments())
 def off(a):
  for s in segs:
   if s['p_type']=='PT_LOAD' and s['p_vaddr']<=a<s['p_vaddr']+s['p_filesz']:return s['p_offset']+a-s['p_vaddr']
  raise ValueError(hex(a))
 def raw(a,expected,new,label):
  o=off(a);old=bytes.fromhex(expected);assert b[o:o+len(old)]==old,(label,b[o:o+len(old)].hex());assert len(old)==len(new)
  patches.append({'label':label,'vaddr':a,'offset':o,'old':old.hex(),'new':new.hex()})
 def hook(a,expected,symbol):
  x=payloads[name]['symbols'][symbol];old=bytes.fromhex(expected);raw(a,expected,b'\xe9'+struct.pack('<i',x-a-5)+b'\x90'*(len(old)-5),symbol)
 patches=[]
 if name=='delivery':
  hook(0x820dfdc,'55 89 e5 53 83 ec 44','update_time')
  hook(0x820f432,'55 89 e5 53 81 ec 74 01 00 00','arrange')
  hook(0x820cfa7,'83 78 10 00 74 47','begin_guard')
  hook(0x820e977,'05 30 2a 00 00','absolute_end')
  for a,old,n in [(0x82125f9,327600,46800),(0x8212609,414000,70200),(0x8212619,416400,70200),(0x8212629,475200,81000)]:raw(a,(b'\x05'+struct.pack('<I',old)).hex(),b'\x05'+struct.pack('<I',n),'daily time offset')
  raw(0x820e0d2,'83 c0 78',b'\x90'*3,'remove 120-second bidding grace')
  raw(0x820c385,'05 58 02 00 00',bytes.fromhex('05 00 00 00 00'),'keep future matches during last ten minutes before start')
  # Rewrite only the call target; original caller manages its own stack.
  a=0x820ea93;old=b'\xe8'+struct.pack('<i',0x820ce58-a-5);new=b'\xe8'+struct.pack('<i',payloads[name]['symbols']['reward']-a-5);raw(a,old.hex(),new,'persistent reward batch guard')
 else:
  hook(0x81a3e44,'55 89 e5 83 ec 08','tick')
  hook(0x81a4ca2,'c7 40 50 00 00 00 00','init_hook')
  hook(0x81a3ce4,'83 ec 0c 8d 45 e8','enter_hook')
  raw(0x81a3fb5,'7e 1b',bytes.fromhex('7c 1b'),'end at deadline rather than after deadline')
 phoff=struct.unpack_from('<I',b,28)[0];phsize,phnum=struct.unpack_from('<HH',b,42)
 notes=[phoff+i*phsize for i in range(phnum) if struct.unpack_from('<I',b,phoff+i*phsize)[0]==4];assert len(notes)==1
 spec[name]={'input_relative':'gdeliveryd/gdeliveryd' if name=='delivery' else 'gs','input_bytes':len(b),'input_sha256':hashlib.sha256(b).hexdigest(),'note_ph_offset':notes[0],'note_ph_old':b[notes[0]:notes[0]+32].hex(),'patches':patches,'payload_file':f'{name}-payload.bin','payload_sha256':hashlib.sha256((w/f'{name}-payload.bin').read_bytes()).hexdigest(),'base':payloads[name]['base'],'memsize':payloads[name]['memsize']}
(w/'patch-spec.json').write_text(json.dumps(spec,indent=2))
print('Guarded spec:',{k:len(v['patches']) for k,v in spec.items()})
