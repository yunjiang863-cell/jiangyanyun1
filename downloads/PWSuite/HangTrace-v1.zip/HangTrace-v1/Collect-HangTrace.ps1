﻿# Read-only observation. No injection, memory writes, packet capture, or executable launch.
param([switch]$SelfTest)
$ErrorActionPreference='Stop'
function Get-ThreadDelta($Before,$After){
 $old=@{};foreach($t in @($Before)){$old[[string]$t.Id]=$t}
 foreach($t in @($After)){
  $prior=$old[[string]$t.Id];$cpu=$null
  if($prior -and $null -ne $prior.CpuMs -and $null -ne $t.CpuMs){$cpu=[Math]::Max(0,$t.CpuMs-$prior.CpuMs)}
  [pscustomobject]@{Id=$t.Id;New=($null -eq $prior);CpuDeltaMs=$cpu;StartAddress=$t.StartAddress}
 }
}
if($SelfTest){
 $a=@([pscustomobject]@{Id=1;CpuMs=10;StartAddress='0x1234'})
 $b=@([pscustomobject]@{Id=1;CpuMs=35;StartAddress='0x1234'},[pscustomobject]@{Id=2;CpuMs=7;StartAddress='0x4567'})
 $r=@(Get-ThreadDelta $a $b)
 if($r.Count -ne 2 -or $r[0].CpuDeltaMs -ne 25 -or -not $r[1].New -or $null -ne $r[1].CpuDeltaMs){throw 'Delta test failed'}
 'PASS: thread delta and new-thread handling';exit
}
if($env:OS -ne 'Windows_NT'){throw 'Please run on Windows.'}
Write-Host '挂机行为采集 v1.0（只读观察，不是函数调用跟踪）' -ForegroundColor Cyan
Write-Host '先进入游戏并打开辅助，但不要开始挂机。报告只保存在本机。'
$games=@(Get-Process -Name elementclient -ErrorAction SilentlyContinue)
if(-not $games.Count){throw '未找到 elementclient.exe，请先进入角色。'}
foreach($g in $games){Write-Host ('PID '+$g.Id+'  '+$g.MainWindowTitle)}
$choice=Read-Host '输入游戏 PID（只有一个时可直接回车）'
if(-not $choice -and $games.Count -eq 1){$gameId=$games[0].Id}else{[int]$gameId=0;if(-not [int]::TryParse($choice,[ref]$gameId) -or $gameId -notin $games.Id){throw '游戏 PID 无效。'}}
$targets=[Collections.Generic.List[object]]::new();$targets.Add((Get-Process -Id $gameId))
$helper=Read-Host '独立辅助的 PID（不清楚或内置辅助直接回车，仅采游戏）'
if($helper){[int]$helperId=0;if(-not [int]::TryParse($helper,[ref]$helperId)){throw '辅助 PID 必须是数字。'};if($helperId -ne $gameId){$targets.Add((Get-Process -Id $helperId))}}
$identities=@{};$configPaths=[Collections.Generic.List[string]]::new()
foreach($t in $targets){
 $identities[[string]$t.Id]=$t.StartTime.ToUniversalTime().Ticks
 try{$exe=$t.Path;if($exe){$cfg=Join-Path ([IO.Path]::GetDirectoryName($exe)) 'Plug.ini';if(Test-Path -LiteralPath $cfg){$configPaths.Add($cfg)}}}catch{}
}
$runName='HangTrace-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)
$out=Join-Path $PSScriptRoot $runName;[void][IO.Directory]::CreateDirectory($out)
$script:Samples=[Collections.Generic.List[object]]::new();$script:Issues=[Collections.Generic.List[object]]::new()
function Observe([string]$Phase){
 $stamp=[DateTime]::UtcNow.ToString('o');$ps=@()
 foreach($target in $targets){
  try{
   $p=Get-Process -Id $target.Id -ErrorAction Stop
   if($p.StartTime.ToUniversalTime().Ticks -ne $identities[[string]$p.Id]){throw '进程已重启，停止使用旧 PID。'}
   $threads=@();$mods=@()
   try{foreach($t in $p.Threads){$cpu=$null;$addr=$null;try{$cpu=$t.TotalProcessorTime.TotalMilliseconds}catch{};try{$addr='0x'+$t.StartAddress.ToInt64().ToString('X')}catch{};$threads+=[pscustomobject]@{Id=$t.Id;CpuMs=$cpu;StartAddress=$addr}}}catch{$script:Issues.Add([pscustomobject]@{Time=$stamp;Pid=$p.Id;Field='threads';Error=$_.Exception.Message})}
   try{foreach($m in $p.Modules){$mods+=[pscustomobject]@{Name=$m.ModuleName;Path=$m.FileName;Base=('0x'+$m.BaseAddress.ToInt64().ToString('X'));Size=$m.ModuleMemorySize}}}catch{$script:Issues.Add([pscustomobject]@{Time=$stamp;Pid=$p.Id;Field='modules';Error=$_.Exception.Message})}
   $ps+=[pscustomobject]@{Pid=$p.Id;Name=$p.ProcessName;CpuMs=$p.TotalProcessorTime.TotalMilliseconds;Threads=$threads;Modules=$mods}
  }catch{$script:Issues.Add([pscustomobject]@{Time=$stamp;Pid=$target.Id;Field='process';Error=$_.Exception.Message})}
 }
 $configs=@();foreach($file in $configPaths){try{$fi=Get-Item -LiteralPath $file;$configs+=[pscustomobject]@{Path=$file;Size=$fi.Length;LastWriteUtc=$fi.LastWriteTimeUtc.ToString('o');Sha256=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash}}catch{$script:Issues.Add([pscustomobject]@{Time=$stamp;Field='Plug.ini';Error=$_.Exception.Message})}}
 $sample=[pscustomobject]@{TimeUtc=$stamp;Phase=$Phase;Processes=$ps;ConfigFiles=$configs};$script:Samples.Add($sample)
 $sample|ConvertTo-Json -Depth 9 -Compress|Add-Content -LiteralPath (Join-Path $out 'samples.jsonl') -Encoding UTF8
}
function Signal([int]$Count){for($i=0;$i -lt $Count;$i++){try{[Console]::Beep(900,200)}catch{};Start-Sleep -Milliseconds 150}}
function Observe-For([string]$Phase,[int]$Seconds){$clock=[Diagnostics.Stopwatch]::StartNew();while($clock.Elapsed.TotalSeconds -lt $Seconds){Observe $Phase;Start-Sleep -Milliseconds 1000}}
Write-Host ''
Write-Host '时序：回车后8秒内切回游戏 → 未挂机采5秒 → 一声提示后点击开始 → 采20秒 → 两声提示后点击停止 → 采10秒。' -ForegroundColor Yellow
Write-Host '请保持同一角色、同一地图。报告含所选进程的模块路径，上传前可检查。'
[void](Read-Host '准备好后按回车')
Start-Sleep -Seconds 8
Observe-For 'baseline' 5
Signal 1
Observe-For 'running-click-start-at-signal' 20
Signal 2
Observe-For 'stopped-click-stop-at-signal' 10
Signal 3
$phaseSummary=@()
foreach($phase in @('baseline','running-click-start-at-signal','stopped-click-stop-at-signal')){
 $samples=@($script:Samples|Where-Object{$_.Phase -eq $phase})
 foreach($target in $targets){
  $observed=@($samples|ForEach-Object{$_.Processes}|Where-Object{$_.Pid -eq $target.Id})
  if($observed.Count -lt 2){continue}
  $first=$observed[0];$last=$observed[-1]
  $phaseSummary+=[pscustomobject]@{Phase=$phase;Pid=$target.Id;Samples=$observed.Count;CpuDeltaMs=($last.CpuMs-$first.CpuMs);ThreadDeltas=@(Get-ThreadDelta $first.Threads $last.Threads|Sort-Object CpuDeltaMs -Descending);FirstModules=$first.Modules;LastModules=$last.Modules}
 }
}
$report=[pscustomobject]@{Version=1;CreatedUtc=[DateTime]::UtcNow.ToString('o');Kind='Read-only process observation';FunctionCallTrace=$false;MemoryRead=$false;ActionsAreUserMarked=$true;Limitations=@('阶段由提示音及用户点击划分，未捕获真实按钮事件。','线程CPU增量不能证明具体技能或选怪行为。','模块枚举可能受权限/位数影响；空列表不代表没有模块。','Plug.ini哈希变化只证明内容变化，不能说明哪个进程读取了它。','没有记录配置读取操作、网络内容、账号密码或进程内存。');Summary=$phaseSummary;Issues=@($script:Issues.ToArray())}
$report|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $out 'report.json') -Encoding UTF8
$zip=$out+'.zip';Compress-Archive -LiteralPath (Join-Path $out 'samples.jsonl'),(Join-Path $out 'report.json') -DestinationPath $zip
Write-Host ('完成，请上传：'+$zip) -ForegroundColor Green
[void](Read-Host '按回车关闭')
