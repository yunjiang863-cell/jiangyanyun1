@echo off
cd /d "%~dp0"
set "TRACE_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "TRACE_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%TRACE_PS%" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-HangTrace.ps1"
if errorlevel 1 pause
