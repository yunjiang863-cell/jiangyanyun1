#!/usr/bin/env python3
"""Read-only local observation; never sends a packet or changes service configuration."""
import argparse,collections,configparser,datetime,hashlib,json,os,pathlib,socket,uuid,zipfile
ROLES=('glinkd','gdeliveryd','gacd')
STATES={'01':'ESTABLISHED','02':'SYN_SENT','03':'SYN_RECV','04':'FIN_WAIT1','05':'FIN_WAIT2','06':'TIME_WAIT','07':'CLOSE','08':'CLOSE_WAIT','09':'LAST_ACK','0A':'LISTEN','0B':'CLOSING'}
def endpoint(text):
 ip,port=text.split(':');return socket.inet_ntoa(bytes.fromhex(ip)[::-1]),int(port,16)
def tcp_table(path):
 rows=[]
 with path.open() as f:
  next(f,None)
  for line in f:
   fields=line.split()
   if len(fields)>=10:
    try:rows.append((fields[9],endpoint(fields[1]),endpoint(fields[2]),STATES.get(fields[3],fields[3])))
    except (ValueError,OSError):continue
 return rows

def inspect(root,proc=pathlib.Path('/proc')):
 issues=[];configs={};expected=None
 for role in ROLES:
  folder=root/role;record={'directory_exists':folder.is_dir(),'config_files':[]}
  if folder.is_dir():
   for f in sorted(folder.iterdir()):
    if not f.is_file() or f.suffix.lower() not in ('.conf','.ini','.cfg'):continue
    item={'name':f.name}
    try:
     if f.stat().st_size>1048576:raise ValueError('config exceeds 1MiB inspection limit')
     cp=configparser.ConfigParser(interpolation=None,strict=False);cp.read_string(f.read_text(encoding='utf-8-sig',errors='replace'))
     item['sections']=cp.sections() # no configuration values or passwords are exported
     if role=='gdeliveryd' and f.name=='gamesys.conf' and cp.has_section('GAntiCheatClient'):
      host=cp.get('GAntiCheatClient','address',fallback='').strip();port=cp.get('GAntiCheatClient','port',fallback='').strip()
      try:socket.inet_aton(host);port=int(port);assert 0<port<=65535;expected=(host,port);item['anticheat_ipv4_endpoint_parseable']=True
      except (OSError,ValueError,AssertionError):item['anticheat_ipv4_endpoint_parseable']=False
    except (OSError,ValueError,configparser.Error) as e:item['inspection_error_type']=type(e).__name__
    record['config_files'].append(item)
  configs[role]=record
 processes=[]
 for directory in proc.iterdir():
  if not directory.name.isdigit():continue
  try:
   name=(directory/'comm').read_text().strip()
   if name not in ROLES:continue
   record={'pid':int(directory.name),'role':name,'socket_states':{},'modules_inspected':False}
   try:
    executable=directory/'exe';sha=hashlib.sha256()
    with executable.open('rb') as f:
     for block in iter(lambda:f.read(65536),b''):sha.update(block)
    record['executable_sha256']=sha.hexdigest()
   except OSError:record['executable_unreadable']=True
   inodes=set()
   try:
    for fd in (directory/'fd').iterdir():
     try:
      target=os.readlink(str(fd))
      if target.startswith('socket:['):inodes.add(target[8:-1])
     except OSError:continue
    record['socket_inventory_available']=True
   except OSError:record['socket_inventory_available']=False
   try:
    # Each process's own network namespace; match ownership through fd inode.
    rows=tcp_table(directory/'net'/'tcp');own=[r for r in rows if r[0] in inodes]
    record['socket_states']=dict(collections.Counter(r[3] for r in own))
    if name=='gdeliveryd':
     record['anticheat_endpoint_known']=expected is not None
     record['matching_configured_anticheat_established']=None if expected is None or not record['socket_inventory_available'] else sum(r[2]==expected and r[3]=='ESTABLISHED' for r in own)
   except OSError:record['tcp_inventory_unavailable']=True
   processes.append(record)
  except (OSError,ValueError):continue
 return {'schema':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':'read-only snapshot, no authentication enforcement','config_metadata':configs,'processes':processes,'limits':['No services executed/restarted and no configuration changed.','No account data, credentials, command lines, log contents, IP addresses or port numbers are exported.','Only IPv4 TCP sockets are inspected; hostnames, Unix sockets and IPv6-only configurations are not resolved.','A matching established connection does not prove the AC protocol or guard validation is working.','Process names are observations, not proof of binary identity; hashes can be compared offline.','Missing/unreadable fd data and process exit races limit completeness.','gacd binary/decision logic still requires separate analysis.']}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',default='/root/pwserver');a=ap.parse_args()
 report=inspect(pathlib.Path(a.root));name='GuardServerCheck-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6]+'.zip'
 data=json.dumps(report,ensure_ascii=False,indent=2).encode()
 with zipfile.ZipFile(name,'x',zipfile.ZIP_DEFLATED) as z:z.writestr('report.json',data)
 print('Saved local report: '+str(pathlib.Path(name).resolve()))
 print('No files have been uploaded. This tool does not install or enable guard authentication.')
if __name__=='__main__':main()
