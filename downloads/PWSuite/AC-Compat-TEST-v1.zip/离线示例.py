from ac_compat import *
# Fabricated records, never player data. No sockets are opened.
records=[(160001+i,160000,0x7f000001) for i in range(5)]
source=struct.pack('!i',5)+compact(5)+b''.join(struct.pack('!III',*r) for r in records)
converted,count=convert_5034(source)
assert len(source)==65 and len(converted)==45 and count==5
print('PASS: fabricated 5034 body (65 bytes, 5 records) -> 5026 body (45 bytes).')
print('No service executed, no files changed, no network connection opened.')
