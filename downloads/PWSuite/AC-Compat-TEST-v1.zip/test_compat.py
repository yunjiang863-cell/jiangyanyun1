import unittest,struct,asyncio
from ac_compat import *
class Codec(unittest.TestCase):
 def body(self,status=5,records=None):
  if records is None:records=[(160001,160000,0x7f000001)]
  return struct.pack('!i',status)+compact(len(records))+b''.join(struct.pack('!III',*r) for r in records)
 def test_boundaries(self):
  fixtures={0:'00',127:'7f',128:'8080',16383:'bfff',16384:'c0004000',0x1fffffff:'dfffffff',0x20000000:'e020000000',0xffffffff:'e0ffffffff'}
  for n,expected in fixtures.items():self.assertEqual(compact(n).hex(),expected);self.assertEqual(parse_compact(bytes.fromhex(expected)),(n,len(bytes.fromhex(expected))))
 def test_conversion(self):
  out,n=convert_5034(self.body());self.assertEqual(n,1);self.assertEqual(out,struct.pack('!iBII',5,1,160001,0x7f000001))
  out,n=convert_5034(self.body(0));self.assertEqual(out[:4],bytes(4))
  out,n=convert_5034(self.body(records=[]));self.assertEqual(n,0);self.assertEqual(out,b'\0\0\0\x05\0')
 def test_observed_length_shape(self):
  b=self.body(records=[(160001+i,160000,0x7f000001) for i in range(5)]);self.assertEqual(len(b),65);out,n=convert_5034(b);self.assertEqual(len(out),45);self.assertEqual(n,5)
 def test_rejects(self):
  for b in [self.body(records=[(160001,777,0x7f000001)]),self.body(1),self.body()[:-1],self.body()+b'x',struct.pack('!i',5)+compact(MAX_RECORDS+1),b'']:
   with self.assertRaises(ProtocolError):convert_5034(b)
  for b in [b'\x80\x01',b'\xe1',b'\xe0\x00\x00\x00\x01']:
   with self.assertRaises(ProtocolError):parse_compact(b)
 def test_fragment_and_coalesce(self):
  a=frame(5002,struct.pack('!ii',1,0));b=frame(5034,self.body());raw=a+b
  for split in range(len(raw)+1):
   f=Frames();out=f.feed(raw[:split])+f.feed(raw[split:]);f.finish();self.assertEqual([p[2] for p in out],[a,b])
  f=Frames();out=[]
  for x in raw:out+=f.feed(bytes([x]))
  f.finish();self.assertEqual(len(out),2)
  f=Frames();f.feed(b[:-1])
  with self.assertRaises(ProtocolError):f.finish()
  with self.assertRaises(ProtocolError):Frames().feed(compact(1)+compact(MAX_BODY+1))
 def test_relay(self):
  loop=asyncio.new_event_loop();asyncio.set_event_loop(loop)
  async def scenario():
   received=[];errors=[]
   async def fake_backend(reader,writer):
    try:
     decoder=Frames()
     while len(received)<2:
      data=await reader.read(4096)
      if not data:raise AssertionError('unexpected disconnect')
      received.extend(decoder.feed(data))
     reply=frame(5031,b'fixture-backend-response')
     writer.write(reply);await writer.drain()
     writer.close()
    except Exception as e:errors.append(e)
   backend=await asyncio.start_server(fake_backend,'127.0.0.1',0)
   port=backend.sockets[0].getsockname()[1];bridge=Bridge(port)
   relay=await asyncio.start_server(bridge.handle,'127.0.0.1',0)
   reader,writer=await asyncio.open_connection('127.0.0.1',relay.sockets[0].getsockname()[1])
   raw=frame(5002,struct.pack('!ii',1,0))+frame(5034,self.body())
   for chunk in [raw[:1],raw[1:4],raw[4:]]:writer.write(chunk);await writer.drain()
   expected=frame(5031,b'fixture-backend-response')
   reply=await asyncio.wait_for(reader.readexactly(len(expected)),3)
   self.assertEqual(reply,expected);self.assertEqual(received[1][0],5026);self.assertEqual(received[1][1],struct.pack('!iBII',5,1,160001,0x7f000001));self.assertFalse(errors)
   writer.close();relay.close();backend.close();await relay.wait_closed();await backend.wait_closed();await asyncio.sleep(0.05)
  try:loop.run_until_complete(scenario())
  finally:
   pending=asyncio.Task.all_tasks(loop=loop) if sys.version_info<(3,7) else asyncio.all_tasks(loop)
   for t in pending:t.cancel()
   loop.run_until_complete(asyncio.sleep(0));loop.close();asyncio.set_event_loop(None)
if __name__=='__main__':unittest.main()
