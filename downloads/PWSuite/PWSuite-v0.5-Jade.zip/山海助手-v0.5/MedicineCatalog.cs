using System;using System.Collections.Generic;using System.IO;using System.Text;
public sealed class PWMedicineDefinition {
 public int Id,MajorType,SubType,RequiredLevel,RawCooldown,HpTotal,HpDuration,MpTotal,MpDuration,MaxStack;
 public string Name;
}
// Template decoder only. It must not be presented as a live inventory reader.
public static class PWMedicineCatalog {
 static readonly int[] Strides={84,68,356,1420,68,72,1128,68,72,1168,68,68};
 public static Dictionary<int,PWMedicineDefinition> Load(string path){
  Dictionary<int,PWMedicineDefinition> result=new Dictionary<int,PWMedicineDefinition>();
  using(BinaryReader r=new BinaryReader(new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite))){
   if(r.BaseStream.Length<12||r.ReadUInt16()!=60||r.ReadUInt16()!=0x3000)throw new InvalidDataException("仅支持已核对的v60 elements.data结构。");
   r.BaseStream.Position=8;
   for(int table=0;table<12;table++){
    uint count=r.ReadUInt32();if(count>1000000)throw new InvalidDataException("模板数量无效。");
    long bytes=(long)count*Strides[table];if(bytes>r.BaseStream.Length-r.BaseStream.Position)throw new InvalidDataException("模板数据不完整。");r.BaseStream.Position+=bytes;
   }
   uint medicines=r.ReadUInt32();if(medicines>100000||(long)medicines*376>r.BaseStream.Length-r.BaseStream.Position)throw new InvalidDataException("药品模板表无效。");
   for(int i=0;i<medicines;i++){
    long start=r.BaseStream.Position;var m=new PWMedicineDefinition();m.Id=r.ReadInt32();m.MajorType=r.ReadInt32();m.SubType=r.ReadInt32();m.Name=Encoding.Unicode.GetString(r.ReadBytes(64)).Split('\0')[0];
    r.BaseStream.Position=start+332;m.RequiredLevel=r.ReadInt32();m.RawCooldown=r.ReadInt32();m.HpTotal=r.ReadInt32();m.HpDuration=r.ReadInt32();m.MpTotal=r.ReadInt32();m.MpDuration=r.ReadInt32();
    r.BaseStream.Position=start+364;m.MaxStack=r.ReadInt32();r.BaseStream.Position=start+376;
    if(m.Id<=0||String.IsNullOrWhiteSpace(m.Name)||result.ContainsKey(m.Id))throw new InvalidDataException("药品ID或名称无效。");result.Add(m.Id,m);
   }
  }
  return result;
 }
}
