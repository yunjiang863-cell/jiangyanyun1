#!/usr/bin/env python3
"""Isolated-test-only loopback ACStatusAnnounce2 adapter. NOT guard authentication."""
import argparse,asyncio,datetime,json,struct,sys,signal
MAX_BODY=1024*1024
MAX_RECORDS=4096
MAX_ACTIVE_ROLES=50000
VERSION="AC-COMPAT-TEST-v2"
class ProtocolError(ValueError):pass
class NeedMore(Exception):pass

def compact(n):
 if not 0<=n<=0xffffffff:raise ProtocolError('compact integer out of range')
 if n<0x80:return bytes([n])
 if n<0x4000:return struct.pack('!H',n|0x8000)
 if n<0x20000000:return struct.pack('!I',n|0xc0000000)
 return b'\xe0'+struct.pack('!I',n)

def parse_compact(data,at=0):
 if at>=len(data):raise NeedMore()
 first=data[at]
 size=1 if first<0x80 else 2 if first<0xc0 else 4 if first<0xe0 else 5 if first==0xe0 else 0
 if not size:raise ProtocolError('invalid compact integer prefix')
 if len(data)<at+size:raise NeedMore()
 raw=bytes(data[at:at+size])
 if size==1:n=first
 elif size==2:n=struct.unpack('!H',raw)[0]&0x3fff
 elif size==4:n=struct.unpack('!I',raw)[0]&0x1fffffff
 else:n=struct.unpack('!I',raw[1:])[0]
 if compact(n)!=raw:raise ProtocolError('noncanonical compact integer')
 return n,at+size

def frame(kind,body):
 if len(body)>MAX_BODY:raise ProtocolError('body too large')
 return compact(kind)+compact(len(body))+body

class Frames:
 def __init__(self):self.data=bytearray()
 def feed(self,data):
  self.data.extend(data);out=[]
  while self.data:
   try:kind,at=parse_compact(self.data);size,at=parse_compact(self.data,at)
   except NeedMore:break
   if size>MAX_BODY:raise ProtocolError('announced body exceeds bound')
   end=at+size
   if len(self.data)<end:break
   raw=bytes(self.data[:end]);body=bytes(self.data[at:end]);del self.data[:end];out.append((kind,body,raw))
  if len(self.data)>MAX_BODY+10:raise ProtocolError('partial frame exceeds bound')
  return out
 def finish(self):
  if self.data:raise ProtocolError('truncated frame at stream close')

class IdentityState:
 def __init__(self):self.roles={}
 def update(self,status,records):
  # Prepare a new state first; a malformed/conflicting batch cannot partially update it.
  next_roles=dict(self.roles);seen=set()
  for role,user,ip in records:
   if not 0<role<=0x7fffffff or (role&0xfffffff0)==0:
    raise ProtocolError('reserved or invalid role id')
   if role in seen:raise ProtocolError('duplicate role in one status batch')
   seen.add(role)
   if status==5:
    if not 0<user<=0x7fffffff:raise ProtocolError('login requires a positive explicit account id')
    prior=next_roles.get(role)
    if prior is not None and prior!=user:raise ProtocolError('active role account changed without logout')
    next_roles[role]=user
   else:
    # Verified RoleLogout constructs (roleid,0,0); 0 is not an unknown account error here.
    prior=next_roles.get(role)
    if user and (not 0<user<=0x7fffffff or (prior is not None and user!=prior)):
     raise ProtocolError('logout account conflicts with active role')
    next_roles.pop(role,None)
  if len(next_roles)>MAX_ACTIVE_ROLES:raise ProtocolError('active role map exceeds bound')
  bases={}
  for role,user in next_roles.items():
   base=role&0xfffffff0
   if base in bases and bases[base]!=user:
    raise ProtocolError('one active role group maps to different accounts')
   bases[base]=user
  self.roles=next_roles

def convert_5034(body,identities=None):
 if len(body)<5:raise ProtocolError('5034 missing header/count')
 status=struct.unpack('!i',body[:4])[0]
 if status not in (0,5):raise ProtocolError('status not supported by verified legacy handler')
 try:count,at=parse_compact(body,4)
 except NeedMore:raise ProtocolError('5034 incomplete count')
 if count>MAX_RECORDS or len(body)!=at+12*count:raise ProtocolError('5034 count/length mismatch')
 records=[struct.unpack('!III',body[at+12*i:at+12*i+12]) for i in range(count)]
 if identities is None:identities=IdentityState()
 identities.update(status,records)
 # Preserve actual roleid and IP. Keep explicit account ids in the connection-local map.
 # The original gdeliveryd (not this relay) resolves role groups to UIDs in GMKickoutUser.
 out=bytearray(body[:4]+compact(count))
 for role,user,ip in records:out.extend(struct.pack('!II',role,ip))
 return bytes(out),count

def log(event,**fields):
 obj={'version':VERSION,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event};obj.update(fields)
 print(json.dumps(obj,separators=(',',':')),flush=True)

class Bridge:
 def __init__(self,upstream_port):self.upstream_port=upstream_port;self.active=False
 async def handle(self,reader,writer):
  if self.active:log('reject_extra_session');writer.close();return
  self.active=True;up_writer=None;tasks=[]
  try:
   up_reader,up_writer=await asyncio.wait_for(asyncio.open_connection('127.0.0.1',self.upstream_port),5)
   identities=IdentityState();log('test_session_open')
   async def pump(source,destination,to_legacy):
    decoder=Frames();first=True
    while True:
     data=await source.read(32768)
     if not data:decoder.finish();log('peer_eof',direction='delivery_to_gacd' if to_legacy else 'gacd_to_delivery');return
     for kind,body,raw in decoder.feed(data):
      if to_legacy and first:
       if kind!=5002 or body!=struct.pack('!ii',1,0):raise ProtocolError('initial delivery identification differs from verified build')
       first=False
      if to_legacy and kind==5034:
       body,count=convert_5034(body,identities);raw=frame(5026,body);log('converted_status',source_type=5034,target_type=5026,records=count,active_roles=len(identities.roles))
      destination.write(raw);await destination.drain()
   tasks=[asyncio.ensure_future(pump(reader,up_writer,True)),asyncio.ensure_future(pump(up_reader,writer,False))]
   done,pending=await asyncio.wait(tasks,return_when=asyncio.FIRST_COMPLETED)
   for task in done:task.result()
  except (ProtocolError,OSError,asyncio.TimeoutError) as error:log('test_session_closed',error_type=type(error).__name__,reason=str(error))
  except Exception as error:log('unexpected_error',error_type=type(error).__name__,reason=str(error))
  finally:
   for task in tasks:
    if not task.done():task.cancel()
   if tasks:await asyncio.gather(*tasks,return_exceptions=True)
   writer.close()
   if up_writer:up_writer.close()
   self.active=False;log('test_session_end')

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--serve-test',action='store_true',help='explicitly start loopback test relay; never use on live service')
 ap.add_argument('--listen-port',type=int,default=29703);ap.add_argument('--upstream-port',type=int,default=29702)
 ap.add_argument('--convert-file',help='convert one offline 5034 payload body (not an entire network capture)')
 ap.add_argument('--output')
 a=ap.parse_args()
 if a.convert_file:
  if a.serve_test or not a.output:ap.error('offline conversion requires --output and no --serve-test')
  with open(a.convert_file,'rb') as f:body=f.read(MAX_BODY+1)
  if len(body)>MAX_BODY:raise ProtocolError('input exceeds bound')
  converted,count=convert_5034(body)
  with open(a.output,'xb') as f:f.write(frame(5026,converted))
  log('offline_conversion',records=count);return
 if not a.serve_test:ap.error('choose --serve-test or --convert-file; no server started')
 if not 1024<=a.listen_port<=65535 or not 1024<=a.upstream_port<=65535 or a.listen_port==a.upstream_port:ap.error('ports must be distinct and within 1024..65535')
 loop=asyncio.get_event_loop();bridge=Bridge(a.upstream_port)
 try:server=loop.run_until_complete(asyncio.start_server(bridge.handle,'127.0.0.1',a.listen_port))
 except OSError as error:log('listen_failed',reason=str(error));loop.close();raise SystemExit(1)
 log('isolated_test_only',listen='127.0.0.1',listen_port=a.listen_port,upstream_port=a.upstream_port,guard_authentication=False)
 if sys.platform!='win32':loop.add_signal_handler(signal.SIGTERM,loop.stop)
 try:loop.run_forever()
 except KeyboardInterrupt:pass
 finally:
  log('server_stopping');server.close();loop.run_until_complete(server.wait_closed())
  pending=asyncio.Task.all_tasks(loop=loop) if sys.version_info<(3,7) else asyncio.all_tasks(loop)
  for t in pending:t.cancel()
  if pending:loop.run_until_complete(asyncio.gather(*pending,return_exceptions=True))
  loop.close()
if __name__=='__main__':main()
