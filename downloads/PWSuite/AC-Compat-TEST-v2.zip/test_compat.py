import unittest,struct,asyncio,subprocess,socket,pathlib,select
from ac_compat import *
class Codec(unittest.TestCase):
 def body(self,status=5,records=None):
  if records is None:records=[(160001,160000,0x7f000001)]
  return struct.pack('!i',status)+compact(len(records))+b''.join(struct.pack('!III',*r) for r in records)
 def test_boundaries(self):
  fixtures={0:'00',127:'7f',128:'8080',16383:'bfff',16384:'c0004000',0x1fffffff:'dfffffff',0x20000000:'e020000000',0xffffffff:'e0ffffffff'}
  for n,expected in fixtures.items():self.assertEqual(compact(n).hex(),expected);self.assertEqual(parse_compact(bytes.fromhex(expected)),(n,len(bytes.fromhex(expected))))
 def test_conversion(self):
  out,n=convert_5034(self.body());self.assertEqual(n,1);self.assertEqual(out,struct.pack('!iBII',5,1,160001,0x7f000001))
  out,n=convert_5034(self.body(0));self.assertEqual(out[:4],bytes(4))
  out,n=convert_5034(self.body(records=[]));self.assertEqual(n,0);self.assertEqual(out,b'\0\0\0\x05\0')
 def test_observed_length_shape(self):
  b=self.body(records=[(160001+i,160000,0x7f000001) for i in range(5)]);self.assertEqual(len(b),65);out,n=convert_5034(b);self.assertEqual(len(out),45);self.assertEqual(n,5)
 def test_rejects(self):
  for b in [self.body(records=[(160001,0,0x7f000001)]),self.body(1),self.body()[:-1],self.body()+b'x',struct.pack('!i',5)+compact(MAX_RECORDS+1),b'']:
   with self.assertRaises(ProtocolError):convert_5034(b)
  for b in [b'\x80\x01',b'\xe1',b'\xe0\x00\x00\x00\x01']:
   with self.assertRaises(ProtocolError):parse_compact(b)
 def test_fragment_and_coalesce(self):
  a=frame(5002,struct.pack('!ii',1,0));b=frame(5034,self.body());raw=a+b
  for split in range(len(raw)+1):
   f=Frames();out=f.feed(raw[:split])+f.feed(raw[split:]);f.finish();self.assertEqual([p[2] for p in out],[a,b])
  f=Frames();out=[]
  for x in raw:out+=f.feed(bytes([x]))
  f.finish();self.assertEqual(len(out),2)
  f=Frames();f.feed(b[:-1])
  with self.assertRaises(ProtocolError):f.finish()
  with self.assertRaises(ProtocolError):Frames().feed(compact(1)+compact(MAX_BODY+1))
 def test_explicit_nonlegacy_account(self):
  state=IdentityState();body=self.body(records=[(32004,88888,0x7f000001)])
  converted,n=convert_5034(body,state)
  self.assertEqual(n,1);self.assertEqual(converted,struct.pack('!iBII',5,1,32004,0x7f000001))
  self.assertEqual(state.roles,{32004:88888})
 def test_zero_account_logout(self):
  state=IdentityState();convert_5034(self.body(records=[(32004,88888,0x7f000001)]),state)
  converted,n=convert_5034(self.body(0,[(32004,0,0)]),state)
  self.assertEqual(state.roles,{});self.assertEqual(converted,struct.pack('!iBII',0,1,32004,0))
 def test_conflicts_atomic(self):
  state=IdentityState();convert_5034(self.body(records=[(32004,88888,1)]),state)
  for records in [[(32005,99999,1)],[(32004,99999,1)],[(32020,77777,1),(32020,77777,1)],[(32020,77777,1),(32004,99999,1)]]:
   with self.assertRaises(ProtocolError):convert_5034(self.body(records=records),state)
   self.assertEqual(state.roles,{32004:88888})
  with self.assertRaises(ProtocolError):convert_5034(self.body(0,[(32004,99999,0)]),state)
  self.assertEqual(state.roles,{32004:88888})
 def test_multiple_roles_and_reconnect(self):
  state=IdentityState();convert_5034(self.body(records=[(32004,88888,1),(32005,88888,1)]),state)
  convert_5034(self.body(0,[(32004,0,0)]),state);self.assertEqual(state.roles,{32005:88888})
  fresh=IdentityState();convert_5034(self.body(records=[(32004,99999,1)]),fresh)
  self.assertEqual(fresh.roles,{32004:99999});self.assertEqual(state.roles,{32005:88888})
 def test_cli_does_not_serve_by_default(self):
  result=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('ac_compat.py'))],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=5)
  self.assertNotEqual(result.returncode,0);self.assertNotIn(b'isolated_test_only',result.stdout)
 def test_bind_conflict_is_not_started(self):
  sock=socket.socket();sock.bind(('127.0.0.1',0));sock.listen(1);port=sock.getsockname()[1]
  try:
   other=port+1 if port<65535 else port-1
   result=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('ac_compat.py')),'--serve-test','--listen-port',str(port),'--upstream-port',str(other)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=5)
   self.assertNotEqual(result.returncode,0);self.assertIn(b'listen_failed',result.stdout);self.assertNotIn(b'isolated_test_only',result.stdout)
  finally:sock.close()
 @unittest.skipIf(sys.platform=='win32','SIGTERM cleanup is Unix-specific')
 def test_sigterm_cleanup(self):
  sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();other=port+1 if port<65535 else port-1
  process=subprocess.Popen([sys.executable,'-u',str(pathlib.Path(__file__).with_name('ac_compat.py')),'--serve-test','--listen-port',str(port),'--upstream-port',str(other)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   ready,_,_=select.select([process.stdout],[],[],5);self.assertTrue(ready)
   first=process.stdout.readline();self.assertIn(b'isolated_test_only',first)
   process.terminate();out,err=process.communicate(timeout=5)
   self.assertEqual(process.returncode,0);self.assertIn(b'server_stopping',out);self.assertNotIn(b'Traceback',err)
  finally:
   if process.poll() is None:process.kill();process.communicate()
 def test_relay(self):
  loop=asyncio.new_event_loop();asyncio.set_event_loop(loop)
  async def scenario():
   received=[];errors=[]
   async def fake_backend(reader,writer):
    try:
     decoder=Frames()
     while len(received)<3:
      data=await reader.read(4096)
      if not data:raise AssertionError('unexpected disconnect')
      received.extend(decoder.feed(data))
     reply=frame(5031,b'fixture-backend-response')
     writer.write(reply);await writer.drain()
     writer.close()
    except Exception as e:errors.append(e)
   backend=await asyncio.start_server(fake_backend,'127.0.0.1',0)
   port=backend.sockets[0].getsockname()[1];bridge=Bridge(port)
   relay=await asyncio.start_server(bridge.handle,'127.0.0.1',0)
   reader,writer=await asyncio.open_connection('127.0.0.1',relay.sockets[0].getsockname()[1])
   raw=frame(5002,struct.pack('!ii',1,0))+frame(5034,self.body(records=[(32004,88888,0x7f000001)]))+frame(5034,self.body(0,[(32004,0,0)]))
   for chunk in [raw[:1],raw[1:4],raw[4:]]:writer.write(chunk);await writer.drain()
   expected=frame(5031,b'fixture-backend-response')
   reply=await asyncio.wait_for(reader.readexactly(len(expected)),3)
   self.assertEqual(reply,expected);self.assertEqual(received[1][0],5026);self.assertEqual(received[1][1],struct.pack('!iBII',5,1,32004,0x7f000001));self.assertEqual(received[2][0],5026);self.assertEqual(received[2][1],struct.pack('!iBII',0,1,32004,0));self.assertFalse(errors)
   writer.close();relay.close();backend.close();await relay.wait_closed();await backend.wait_closed();await asyncio.sleep(0.05)
  try:loop.run_until_complete(scenario())
  finally:
   pending=asyncio.Task.all_tasks(loop=loop) if sys.version_info<(3,7) else asyncio.all_tasks(loop)
   for t in pending:t.cancel()
   loop.run_until_complete(asyncio.sleep(0));loop.close();asyncio.set_event_loop(None)
if __name__=='__main__':unittest.main()
