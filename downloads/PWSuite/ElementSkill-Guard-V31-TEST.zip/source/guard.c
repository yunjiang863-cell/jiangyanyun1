#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#define BUILD "PWGUARD-V31-20261101"
#define CACHE_SIZE 512
#define RECHECK_MS 15000ULL
static HMODULE self;
static WCHAR dllpath[32768],original[32768],logpath[32768],imagepath[32768];
static BYTE hashbuf[32768];
static const char *original_sha="D323898D5AD0058F88601F9A5993E37766A7A7AD18750656FF379AA3784D5F75";
static const WCHAR *names[]={L"古叶免费辅助2.53.exe",L"古叶免费辅助2.54.exe",L"古叶免费辅助.exe",L"古叶综合辅助.exe",L"完美魔方.exe",L"辅助控制面板.exe",L"311WM完美情人免费辅助.exe",L"AiPerfect.exe"};
static const char *hashes[]={"595D754DE3B32E52EC5FE244F868ADEE33511AF26289959863BDA94F618C097F","FB04015DCB95E0CA972B83FFD08BC8B0BC6F053B4A65310FFBC3408296AA7A32","44DF4A31D6465E230DDE3338B3D9855FD02EEAF56FA8D97EC7F35E6CB3AEC767","F065BC460F794F6DE5393BE5B067421B409BDD4EF9FFBE293B2871055BD1C981","9B3C9BB4C69F8F1827624F588EC91AA6A30B340BF38943815BB66B1A717C2CA6","268BEE610460B03804D5CAD1ACACAB4389565579DCF5B552C6326AB0AD1E28A7"};
/* A failed inspection is NEVER cached as a clean result. */
struct Seen {DWORD pid;FILETIME created,written;DWORD sizeLow,sizeHigh;ULONGLONG checked;BOOL valid;};
static struct Seen cache[CACHE_SIZE];static DWORD slot;
static void event(const char *what,DWORD detail,const WCHAR *value){
 SYSTEMTIME t;GetLocalTime(&t);char utf[1000],line[1600];utf[0]=0;
 if(value){int n=lstrlenW(value);if(n>300)n=300;int bytes=WideCharToMultiByte(CP_UTF8,0,value,n,utf,999,0,0);if(bytes>0)utf[bytes]=0;}
 int len=wsprintfA(line,"%04u-%02u-%02u %02u:%02u:%02u pid=%lu build=%s event=%s detail=%lu value=%s\r\n",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond,GetCurrentProcessId(),BUILD,what,detail,utf);
 HANDLE f=CreateFileW(logpath,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 if(f!=INVALID_HANDLE_VALUE){DWORD done;WriteFile(f,line,(DWORD)len,&done,0);CloseHandle(f);}else{OutputDebugStringA(line);}
}
static BOOL init_paths(void){
 DWORD n=GetModuleFileNameW(self,dllpath,32768);if(!n||n>=32600)return FALSE;
 lstrcpyW(original,dllpath);while(n&&original[n-1]!=L'\\')--n;if(!n)return FALSE;original[n]=0;
 lstrcpyW(logpath,original);lstrcatW(logpath,L"PWClientGuard-dll.log");lstrcatW(original,L"PWSkillOriginal.dll");
 HANDLE f=CreateFileW(logpath,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,0,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 if(f!=INVALID_HANDLE_VALUE){CloseHandle(f);return TRUE;}
 n=GetEnvironmentVariableW(L"LOCALAPPDATA",logpath,32000);if(!n||n>=32000)return TRUE;
 lstrcatW(logpath,L"\\PWClientGuard");CreateDirectoryW(logpath,0);WCHAR suffix[64];wsprintfW(suffix,L"\\PWClientGuard-%lu.log",GetCurrentProcessId());lstrcatW(logpath,suffix);return TRUE;
}
static void stop_game(const char *reason,DWORD detected,const WCHAR *name){
 event(reason,detected,name);
 for(;;){if(TerminateProcess(GetCurrentProcess(),0xE0470003u))return;event("terminate_failed",GetLastError(),0);Sleep(1000);}
}
static BOOL sha256(const WCHAR *path,char hex[65]){
 BOOL ok=FALSE;HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,0);
 if(file==INVALID_HANDLE_VALUE)return FALSE;
 BCRYPT_ALG_HANDLE alg=0;BCRYPT_HASH_HANDLE hash=0;BYTE digest[32];DWORD n;
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,0,0)<0)goto done;
 if(BCryptCreateHash(alg,&hash,0,0,0,0,0)<0)goto done;
 for(;;){if(!ReadFile(file,hashbuf,sizeof(hashbuf),&n,0))goto done;if(!n)break;if(BCryptHashData(hash,hashbuf,n,0)<0)goto done;}
 if(BCryptFinishHash(hash,digest,32,0)<0)goto done;
 const char *digits="0123456789ABCDEF";for(int i=0;i<32;++i){hex[2*i]=digits[digest[i]>>4];hex[2*i+1]=digits[digest[i]&15];}hex[64]=0;ok=TRUE;
 done:if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);CloseHandle(file);return ok;
}
static BOOL file_stamp(const WCHAR *path,WIN32_FILE_ATTRIBUTE_DATA *s){return GetFileAttributesExW(path,GetFileExInfoStandard,s)&&!(s->dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY);}
static struct Seen *find_seen(DWORD pid,FILETIME *c){for(DWORD i=0;i<CACHE_SIZE;++i)if(cache[i].valid&&cache[i].pid==pid&&CompareFileTime(&cache[i].created,c)==0)return &cache[i];return 0;}
static DWORD WINAPI worker(void *unused){
 (void)unused;if(!init_paths()){TerminateProcess(GetCurrentProcess(),0xE0470004u);return 0;}
 event("started",3,dllpath);static WCHAR host[32768];GetModuleFileNameW(0,host,32768);event("host",0,host);
 event("log_path",0,logpath);
 char hex[65];
 if(!sha256(original,hex)||lstrcmpA(hex,original_sha)!=0){stop_game("original_missing_or_wrong_hash",GetLastError(),original);return 0;}
 event("original_verified",107,original);
 ULONGLONG heartbeat=0;BOOL ready=FALSE;
 for(;;){
  DWORD examined=0,denied=0,failed=0,hashed=0,cached=0;ULONGLONG now=GetTickCount64();
  HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
  if(snapshot==INVALID_HANDLE_VALUE){event("snapshot_failed",GetLastError(),0);Sleep(1000);continue;}
  PROCESSENTRY32W e;e.dwSize=sizeof(e);
  if(!Process32FirstW(snapshot,&e)){event("process_first_failed",GetLastError(),0);CloseHandle(snapshot);Sleep(1000);continue;}
  do{
   if(!e.th32ProcessID||e.th32ProcessID==GetCurrentProcessId())continue;
   ++examined;
   for(unsigned i=0;i<sizeof(names)/sizeof(names[0]);++i){if(lstrcmpiW(e.szExeFile,names[i])==0){CloseHandle(snapshot);stop_game("hit_exact_name",e.th32ProcessID,e.szExeFile);return 0;}}
   HANDLE proc=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,e.th32ProcessID);
   if(!proc){++denied;continue;}
   DWORD cap=32768;FILETIME c,x,k,u;
   if(!GetProcessTimes(proc,&c,&x,&k,&u)||!QueryFullProcessImageNameW(proc,0,imagepath,&cap)){++failed;CloseHandle(proc);continue;}
   /* Some image basenames differ from the snapshot; check both observations. */
   WCHAR *base=imagepath;for(WCHAR *p=imagepath;*p;++p)if(*p==L'\\'||*p==L'/')base=p+1;
   for(unsigned i=0;i<sizeof(names)/sizeof(names[0]);++i){if(lstrcmpiW(base,names[i])==0){CloseHandle(proc);CloseHandle(snapshot);stop_game("hit_image_name",e.th32ProcessID,base);return 0;}}
   WIN32_FILE_ATTRIBUTE_DATA before,after;
   if(!file_stamp(imagepath,&before)){++failed;CloseHandle(proc);continue;}
   struct Seen *seen=find_seen(e.th32ProcessID,&c);
   if(seen&&now-seen->checked<RECHECK_MS&&seen->sizeLow==before.nFileSizeLow&&seen->sizeHigh==before.nFileSizeHigh&&CompareFileTime(&seen->written,&before.ftLastWriteTime)==0){++cached;CloseHandle(proc);continue;}
   /* Large executable images are not hashed here; explicitly count incomplete coverage. */
   if(before.nFileSizeHigh||before.nFileSizeLow>64u*1024u*1024u){++failed;CloseHandle(proc);continue;}
   if(!sha256(imagepath,hex)){++failed;CloseHandle(proc);continue;}++hashed;
   for(unsigned i=0;i<sizeof(hashes)/sizeof(hashes[0]);++i){if(lstrcmpA(hex,hashes[i])==0){CloseHandle(proc);CloseHandle(snapshot);stop_game("hit_sha256",e.th32ProcessID,imagepath);return 0;}}
   if(file_stamp(imagepath,&after)&&before.nFileSizeLow==after.nFileSizeLow&&before.nFileSizeHigh==after.nFileSizeHigh&&CompareFileTime(&before.ftLastWriteTime,&after.ftLastWriteTime)==0){
    if(!seen){seen=&cache[slot++%CACHE_SIZE];}seen->pid=e.th32ProcessID;seen->created=c;seen->written=after.ftLastWriteTime;seen->sizeLow=after.nFileSizeLow;seen->sizeHigh=after.nFileSizeHigh;seen->checked=GetTickCount64();seen->valid=TRUE;
   }
   CloseHandle(proc);
  }while(Process32NextW(snapshot,&e));
  DWORD endError=GetLastError();CloseHandle(snapshot);if(endError!=ERROR_NO_MORE_FILES){event("enumeration_incomplete",endError,0);}
  if(!ready){event("first_scan_complete",examined,0);ready=TRUE;}
  if(!heartbeat||GetTickCount64()-heartbeat>=30000){WCHAR counts[160];wsprintfW(counts,L"scanned=%lu hashed=%lu cached=%lu inaccessible=%lu incomplete=%lu",examined,hashed,cached,denied,failed);event("heartbeat",0,counts);heartbeat=GetTickCount64();}
  Sleep(1000);
 }
 return 0;
}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID reserved){
 (void)reserved;if(reason==DLL_PROCESS_ATTACH){self=instance;DisableThreadLibraryCalls(instance);HANDLE t=CreateThread(0,0,worker,0,0,0);if(!t)return FALSE;CloseHandle(t);}return TRUE;
}
